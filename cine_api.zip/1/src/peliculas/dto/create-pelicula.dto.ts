export class CreatePeliculaDto {}
