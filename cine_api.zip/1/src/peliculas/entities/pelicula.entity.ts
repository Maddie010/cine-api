export class Pelicula {}
