export class Sala {}
