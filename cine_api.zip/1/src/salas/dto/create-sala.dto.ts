export class CreateSalaDto {}
