export class Genero {}
