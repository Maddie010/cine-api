export class CreateGeneroDto {}
