export class CreateBoletoDto {}
