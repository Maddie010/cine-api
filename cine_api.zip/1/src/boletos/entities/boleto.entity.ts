export class Boleto {}
