export class Funcione {}
