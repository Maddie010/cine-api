export class CreateFuncioneDto {}
