export class CreateClienteDto {}
